#include <iostream>
#include <windows.h>

using namespace std;

LRESULT CALLBACK Window_and_Print_Board(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam) {
    static HBITMAP hBitmap = NULL;

    switch (uMsg) {
    case WM_CREATE: {
        hBitmap = (HBITMAP)LoadImage(NULL, "C:\\Users\\tab\\Downloads\\ok\\IMG_20250110_235705.bmp", IMAGE_BITMAP, 0, 0, LR_LOADFROMFILE);
        
        CreateWindow(
            "BUTTON", 
            "ajab",
            WS_TABSTOP | WS_VISIBLE | WS_CHILD | BS_PUSHBUTTON,
            975,
            34, 
            80,
            32,
            hwnd,
            (HMENU)1,  
            (HINSTANCE)GetWindowLongPtr(hwnd, GWLP_HINSTANCE),
            NULL);   

        HRGN hRgn = CreateRoundRectRgn(20, 20, 400, 50, 50, 50);
        HWND hLabel = CreateWindow("STATIC", "khobeh",
            WS_VISIBLE | WS_CHILD, 15, 35, 950, 30,
            hwnd, nullptr, nullptr, nullptr);
        HWND hLabel1 = CreateWindow("STATIC", "Maze_Project_for_BP_Class | Teacher : Taybeh Rafiei | 1403_1404",
            WS_VISIBLE | WS_CHILD, 15, 5, 1040, 20,
            hwnd, nullptr, nullptr, nullptr);
        SetWindowRgn(hLabel, hRgn, TRUE);
        SetWindowRgn(hLabel1, hRgn, TRUE);
        break;
    }
    
    case WM_COMMAND: {
        if (LOWORD(wParam) == 1) {
            MessageBox(hwnd, "", "ajab", MB_OK);
        }
    } break;

    case WM_DESTROY:
        DeleteObject(hBitmap);
        PostQuitMessage(0);
        return 0;

    case WM_SIZE:
        SetWindowPos(hwnd, NULL, 0, 0, 1080, 720, SWP_NOZORDER);
        return 0;

    case WM_PAINT: {
        PAINTSTRUCT ps;
        HDC hdc = BeginPaint(hwnd, &ps);
        
        HPEN hPenRed = CreatePen(PS_SOLID, 5, RGB(255, 0, 0));
        SelectObject(hdc, hPenRed);
        MoveToEx(hdc, 17, 25, NULL);
        LineTo(hdc, 1052, 25);
        
        if (hBitmap) {
            HDC hdcMem = CreateCompatibleDC(hdc);
            SelectObject(hdcMem, hBitmap);
            BITMAP bitmap;
            GetObject(hBitmap, sizeof(bitmap), &bitmap);
            BitBlt(hdc, 10, 10, bitmap.bmWidth, bitmap.bmHeight, hdcMem, 0, 0, SRCCOPY);
            DeleteDC(hdcMem);
        }
        
        EndPaint(hwnd, &ps);
        break; // اضافه کردن break
    }
        case WM_ERASEBKGND:
    		{
        	HDC hdc = (HDC)wParam;
        	RECT rect;
        	GetClientRect(hwnd, &rect);
        	HBRUSH brush = CreateSolidBrush(RGB(255, 255, 255));
        	FillRect(hdc, &rect, brush);
        	DeleteObject(brush);
        	return 1;
    		}
            return 0;
    }
    return DefWindowProc(hwnd, uMsg, wParam, lParam);
}

int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE, LPSTR, int nShowCmd) {
    const char CLASS_NAME[] = "Sample Window Class";

    WNDCLASS wc = {};
    wc.lpfnWndProc = Window_and_Print_Board;
    wc.hInstance = hInstance;
    wc.lpszClassName = CLASS_NAME;

    RegisterClass(&wc);

    HWND hwnd = CreateWindowEx(
        0,
        CLASS_NAME,
        "Maze Project",
        WS_OVERLAPPEDWINDOW & ~WS_MAXIMIZEBOX,
        CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT,
        NULL,
        NULL,
        hInstance,
        NULL
    );

    ShowWindow(hwnd, nShowCmd);

    MSG msg;
    while (GetMessage(&msg, NULL, 0, 0)) {
        TranslateMessage(&msg);
        DispatchMessage(&msg);
    }

    return 0;
}