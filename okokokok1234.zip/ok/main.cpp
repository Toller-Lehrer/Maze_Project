// include

#include <iostream>
#include <fstream>
#include <vector>
#include <windows.h>

using namespace std;

// function

void Board(){
	
}

LRESULT CALLBACK Window_and_Print_Board(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam) {
    switch (uMsg) {
    	
    	case WM_CREATE: {
    		CreateWindow(
            "BUTTON", 
            "ajab",
            WS_TABSTOP | WS_VISIBLE | WS_CHILD | BS_PUSHBUTTON,
            975,
            34, 
            80,
            32,
            hwnd,
            (HMENU)1,  
            (HINSTANCE)GetWindowLongPtr(hwnd, GWLP_HINSTANCE),
            NULL);   
    		
    		HRGN hRgn = CreateRoundRectRgn(20, 20, 400, 50, 50, 50);
            HWND hLabel = CreateWindow("STATIC", "khobeh",
                         WS_VISIBLE | WS_CHILD, 15, 35, 950, 30,
                         hwnd, nullptr, nullptr, nullptr);
            HWND hLabel1 = CreateWindow("STATIC", " Maze_Project_for_BP_Class                                        |                                         Teacher : Taybeh Rafiei                                |                                        1403_1404",
                         WS_VISIBLE | WS_CHILD, 15, 5, 1040, 20,
                         hwnd, nullptr, nullptr, nullptr);
            SetWindowRgn(hLabel , hRgn, TRUE);
            SetWindowRgn(hLabel1 , hRgn, TRUE);
            break;
        }
        
        case WM_COMMAND: {
	        if (LOWORD(wParam) == 1) {
	            MessageBox(hwnd, "", "ajab", MB_OK);
	        }
	    } break;
        case WM_DESTROY:
            PostQuitMessage(0);
            return 0;
        case WM_SIZE:
            SetWindowPos(hwnd, NULL, 0, 0, 1080, 720, SWP_NOZORDER);
            return 0;
        case WM_PAINT:
            {
                PAINTSTRUCT ps;
                HDC hdc = BeginPaint(hwnd, &ps);
                
				HPEN hPenRed = CreatePen(PS_SOLID, 5, RGB(255, 0, 0));
        		SelectObject(hdc, hPenRed);
                MoveToEx(hdc, 17, 25, NULL);
                LineTo(hdc,1052, 25);
                
                HPEN hPenRed1 = CreatePen(PS_SOLID, 5, RGB(255, 0, 0));
        		SelectObject(hdc, hPenRed1);
                MoveToEx(hdc, 66, 75, NULL);
                LineTo(hdc,66, 625);
                
                HPEN hPenRed2 = CreatePen(PS_SOLID, 5, RGB(255, 0, 0));
        		SelectObject(hdc, hPenRed2);
                MoveToEx(hdc, 66, 75, NULL);
                LineTo(hdc,496, 75);
                
                HPEN hPenRed3 = CreatePen(PS_SOLID, 5, RGB(255, 0, 0));
        		SelectObject(hdc, hPenRed3);
                MoveToEx(hdc, 516, 75, NULL);
                LineTo(hdc,1006, 75);
                
                HPEN hPenRed4 = CreatePen(PS_SOLID, 5, RGB(255, 0, 0));
        		SelectObject(hdc, hPenRed4);
                MoveToEx(hdc, 66, 625, NULL);
                LineTo(hdc,106, 625);
                
                HPEN hPenRed5 = CreatePen(PS_SOLID, 5, RGB(255, 0, 0));
        		SelectObject(hdc, hPenRed5);
                MoveToEx(hdc, 106, 550, NULL);
                LineTo(hdc,106, 625);
                
                HPEN hPenRed6 = CreatePen(PS_SOLID, 5, RGB(255, 0, 0));
        		SelectObject(hdc, hPenRed6);
                MoveToEx(hdc, 126, 575, NULL);
                LineTo(hdc,126, 625);
                
                HPEN hPenRed7 = CreatePen(PS_SOLID, 5, RGB(255, 0, 0));
        		SelectObject(hdc, hPenRed7);
                MoveToEx(hdc, 126, 625, NULL);
                LineTo(hdc,526, 625);
				
				HPEN hPenRed8 = CreatePen(PS_SOLID, 5, RGB(255, 0, 0));
        		SelectObject(hdc, hPenRed8);
                MoveToEx(hdc, 526, 575, NULL);
                LineTo(hdc,526, 625);
                
                HPEN hPenRed9 = CreatePen(PS_SOLID, 5, RGB(255, 0, 0));
        		SelectObject(hdc, hPenRed9);
                MoveToEx(hdc, 546, 575, NULL);
                LineTo(hdc,546, 625);
                
                HPEN hPenRed10 = CreatePen(PS_SOLID, 5, RGB(255, 0, 0));
        		SelectObject(hdc, hPenRed10);
                MoveToEx(hdc, 546, 600, NULL);
                LineTo(hdc,576, 600);
                
//                HPEN hPenRed11 = CreatePen(PS_SOLID, 5, RGB(255, 0, 0));
//        		SelectObject(hdc, hPenRed11);
//                MoveToEx(hdc, 546, 600, NULL);
//                LineTo(hdc,576, 600);
                
                HPEN hPenRed12 = CreatePen(PS_SOLID, 5, RGB(255, 0, 0));
        		SelectObject(hdc, hPenRed12);
                MoveToEx(hdc, 546, 625, NULL);
                LineTo(hdc,946, 625);
                
                HPEN hPenRed13 = CreatePen(PS_SOLID, 5, RGB(255, 0, 0));
        		SelectObject(hdc, hPenRed13);
                MoveToEx(hdc, 946, 600, NULL);
                LineTo(hdc,946, 625);
                
                HPEN hPenRed14 = CreatePen(PS_SOLID, 5, RGB(255, 0, 0));
        		SelectObject(hdc, hPenRed14);
                MoveToEx(hdc, 946, 600, NULL);
                LineTo(hdc,946, 625);
                
                HPEN hPenRed15 = CreatePen(PS_SOLID, 5, RGB(255, 0, 0));
        		SelectObject(hdc, hPenRed15);
                MoveToEx(hdc, 966, 625, NULL);
                LineTo(hdc,1006, 625);
                
                HPEN hPenRed16 = CreatePen(PS_SOLID, 5, RGB(255, 0, 0));
        		SelectObject(hdc, hPenRed16);
                MoveToEx(hdc, 966, 625, NULL);
                LineTo(hdc,966, 575);
                
                HPEN hPenRed17 = CreatePen(PS_SOLID, 5, RGB(255, 0, 0));
        		SelectObject(hdc, hPenRed17);
                MoveToEx(hdc, 1006, 75, NULL);
                LineTo(hdc,1006, 625);
                
                HPEN hPenRed18 = CreatePen(PS_SOLID, 5, RGB(255, 0, 0));
        		SelectObject(hdc, hPenRed18);
                MoveToEx(hdc, 946, 575, NULL);
                LineTo(hdc,966, 575);
                
                HPEN hPenRed19 = CreatePen(PS_SOLID, 5, RGB(255, 0, 0));
        		SelectObject(hdc, hPenRed19);
                MoveToEx(hdc, 126, 600, NULL);
                LineTo(hdc,226, 600);
                
                HPEN hPenRed20 = CreatePen(PS_SOLID, 5, RGB(255, 0, 0));
        		SelectObject(hdc, hPenRed20);
                MoveToEx(hdc, 226, 575, NULL);
                LineTo(hdc,226, 600);
                
                HPEN hPenRed21 = CreatePen(PS_SOLID, 5, RGB(255, 0, 0));
        		SelectObject(hdc, hPenRed21);
                MoveToEx(hdc, 226, 575, NULL);
                LineTo(hdc,296, 575);
                
                HPEN hPenRed22 = CreatePen(PS_SOLID, 5, RGB(255, 0, 0));
        		SelectObject(hdc, hPenRed22);
                MoveToEx(hdc, 256, 575, NULL);
                LineTo(hdc,256, 600);
                
                HPEN hPenRed23 = CreatePen(PS_SOLID, 5, RGB(255, 0, 0));
        		SelectObject(hdc, hPenRed23);
                MoveToEx(hdc, 296, 550, NULL);
                LineTo(hdc,296, 575);
                
                HPEN hPenRed24 = CreatePen(PS_SOLID, 5, RGB(255, 0, 0));
        		SelectObject(hdc, hPenRed24);
                MoveToEx(hdc, 296, 600, NULL);
                LineTo(hdc,296, 625);
                
                HPEN hPenRed25 = CreatePen(PS_SOLID, 5, RGB(255, 0, 0));
        		SelectObject(hdc, hPenRed25);
                MoveToEx(hdc, 296, 600, NULL);
                LineTo(hdc,326, 600);
                
                HPEN hPenRed26 = CreatePen(PS_SOLID, 5, RGB(255, 0, 0));
        		SelectObject(hdc, hPenRed26);
                MoveToEx(hdc, 326, 525, NULL);
                LineTo(hdc,326, 600);
                
                HPEN hPenRed27 = CreatePen(PS_SOLID, 5, RGB(255, 0, 0));
        		SelectObject(hdc, hPenRed27);
                MoveToEx(hdc, 326, 575, NULL);
                LineTo(hdc,326, 575);
                
                HPEN hPenRed28 = CreatePen(PS_SOLID, 5, RGB(255, 0, 0));
        		SelectObject(hdc, hPenRed28);
                MoveToEx(hdc, 326, 550, NULL);
                LineTo(hdc,456, 550);
                
                HPEN hPenRed29 = CreatePen(PS_SOLID, 5, RGB(255, 0, 0));
        		SelectObject(hdc, hPenRed29);
                MoveToEx(hdc, 426, 525, NULL);
                LineTo(hdc,426, 575);
                
                HPEN hPenRed30 = CreatePen(PS_SOLID, 5, RGB(255, 0, 0));
        		SelectObject(hdc, hPenRed30);
                MoveToEx(hdc, 426, 525, NULL);
                LineTo(hdc,426, 575);
                
                HPEN hPenRed31 = CreatePen(PS_SOLID, 5, RGB(255, 0, 0));
        		SelectObject(hdc, hPenRed31);
                MoveToEx(hdc, 366, 575, NULL);
                LineTo(hdc,366, 625);
                
                HPEN hPenRed32 = CreatePen(PS_SOLID, 5, RGB(255, 0, 0));
        		SelectObject(hdc, hPenRed32);
                MoveToEx(hdc, 396, 575, NULL);
                LineTo(hdc,396, 600);
                
                HPEN hPenRed33 = CreatePen(PS_SOLID, 5, RGB(255, 0, 0));
        		SelectObject(hdc, hPenRed33);
                MoveToEx(hdc, 366, 575, NULL);
                LineTo(hdc,396, 575);
                
                HPEN hPenRed34 = CreatePen(PS_SOLID, 5, RGB(255, 0, 0));
        		SelectObject(hdc, hPenRed34);
                MoveToEx(hdc, 396, 625, NULL);
                LineTo(hdc,466, 625);
                
                HPEN hPenRed35 = CreatePen(PS_SOLID, 5, RGB(255, 0, 0));
        		SelectObject(hdc, hPenRed35);
                MoveToEx(hdc, 396, 625, NULL);
                LineTo(hdc,466, 625);
                
//                HPEN hPenRed35 = CreatePen(PS_SOLID, 5, RGB(255, 0, 0));
//        		SelectObject(hdc, hPenRed35);
//                MoveToEx(hdc, 396, 625, NULL);
//                LineTo(hdc, 466, 625);
                
                EndPaint(hwnd, &ps);
            }
        case WM_ERASEBKGND:
    		{
        	HDC hdc = (HDC)wParam;
        	RECT rect;
        	GetClientRect(hwnd, &rect);
        	HBRUSH brush = CreateSolidBrush(RGB(125, 45, 255));
        	FillRect(hdc, &rect, brush);
        	DeleteObject(brush);
        	return 1;
    		}
            return 0;
    }
    return DefWindowProc(hwnd, uMsg, wParam, lParam);
}

int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE, LPSTR, int nShowCmd) {
    const char CLASS_NAME[] = "Sample Window Class";

    WNDCLASS wc = {};
    wc.lpfnWndProc = Window_and_Print_Board;
    wc.hInstance = hInstance;
    wc.lpszClassName = CLASS_NAME;

    RegisterClass(&wc);

    HWND hwnd = CreateWindowEx(
        0,
        CLASS_NAME,
        "Maze Project",
        WS_OVERLAPPEDWINDOW & ~WS_MAXIMIZEBOX,
        CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT,
        NULL,
        NULL,
        hInstance,
        NULL
    );

    ShowWindow(hwnd, nShowCmd);

    MSG msg;
    while (GetMessage(&msg, NULL, 0, 0)) {
        TranslateMessage(&msg);
        DispatchMessage(&msg);
    }

    return 0;
}